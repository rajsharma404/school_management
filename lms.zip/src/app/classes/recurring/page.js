import BredCrumb from '@/app/Components/breadcrumb/BreadCrumb'
import React from 'react'

const page = () => {
  return (
    <div>
      <BredCrumb title="Recurring" />
      <h1>Recurring</h1>
    </div>
  )
}

export default page
